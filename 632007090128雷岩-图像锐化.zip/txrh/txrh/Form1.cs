namespace txrh
{
    public partial class Form1 : Form
    {
        Bitmap bt1;
        Bitmap bt2;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)//��ͼƬ
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = Image.FromFile(openFileDialog1.FileName);
                pictureBox1.Width = pictureBox1.Image.Width;
                pictureBox1.Height = pictureBox1.Image.Height;
            }
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)//ȷ����ť
        {
            if (pictureBox1.Image == null)
            {
                MessageBox.Show("δ��ͼƬ��");
                return;
            }
            if (radioButton1.Checked)//ˮƽ��ַ�
            {
                bt1 = new Bitmap(pictureBox1.Image);
                bt2 = new Bitmap(pictureBox1.Image);
                int R1, R2, R3, R4;
                int G1, G2, G3, G4;
                int B1, B2, B3, B4;
                for (int i = 0; i < bt1.Width - 1; i++)
                {
                    for (int j = 0; j < bt1.Height - 1; j++)
                    {
                        //ȡ����������ĺ�ֵ
                        R1 = bt1.GetPixel(i, j).R;
                        R2 = bt1.GetPixel(i + 1, j).R;
                        R3 = bt1.GetPixel(i, j + 1).R;
                        R4 = Math.Abs(R1 - R2) + Math.Abs(R1 - R3);
                        G1 = bt1.GetPixel(i, j).G;
                        G2 = bt1.GetPixel(i + 1, j).G;
                        G3 = bt1.GetPixel(i, j + 1).G;
                        G4 = Math.Abs(G1 - G2) + Math.Abs(G1 - G3);
                        B1 = bt1.GetPixel(i, j).B;
                        B2 = bt1.GetPixel(i + 1, j).B;
                        B3 = bt1.GetPixel(i, j + 1).B;
                        B4 = Math.Abs(B1 - B2) + Math.Abs(B1 - B3);
                        if (R4 >= 255) R4 = 255;
                        if (G4 >= 255) G4 = 255;//�ж��Ƿ񳬳������������ķ�Χ���������255��ֻ�ܵ���255
                        if (B4 >= 255) B4 = 255;
                        bt2.SetPixel(i, j, Color.FromArgb(R4, G4, B4));
                    }
                    pictureBox2.Refresh();
                    pictureBox2.Image = bt2;
                }
            }
            else if (radioButton2.Checked)//soble ����
            {
                bt1 = new Bitmap(pictureBox1.Image);
                bt2 = new Bitmap(pictureBox1.Image);
                int R0, R1, R2, R3, R4;
                int G0, G1, G2, G3, G4;
                int B0, B1, B2, B3, B4;
                for (int i = 0; i < bt1.Width - 1; i++)
                {
                    for (int j = 0; j < bt1.Height - 1; j++)
                    {
                        R1 = bt1.GetPixel(i, j).R;
                        R2 = bt1.GetPixel(i + 1, j).R;
                        R3 = bt1.GetPixel(i, j + 1).R;
                        R0 = bt1.GetPixel(i + 1, j + 1).R;
                        R4 = Math.Abs(R1 - R0) + Math.Abs(R2 - R3);
                        G1 = bt1.GetPixel(i, j).G;
                        G2 = bt1.GetPixel(i + 1, j).G;
                        G3 = bt1.GetPixel(i, j + 1).G;
                        G0 = bt1.GetPixel(i + 1, j + 1).G;
                        G4 = Math.Abs(G1 - G0) + Math.Abs(G2 - G3);
                        B1 = bt1.GetPixel(i, j).B;
                        B2 = bt1.GetPixel(i + 1, j).B;
                        B3 = bt1.GetPixel(i, j + 1).B;
                        B0 = bt1.GetPixel(i + 1, j + 1).B;
                        B4 = Math.Abs(B1 - B0) + Math.Abs(B2 - B3);
                        if (R4 >= 255) R4 = 255;
                        if (G4 >= 255) G4 = 255;//�ж��Ƿ񳬳������������ķ�Χ���������255��ֻ�ܵ���255
                        if (B4 >= 255) B4 = 255;
                        bt2.SetPixel(i, j, Color.FromArgb(R4, G4, B4));
                    }
                    pictureBox2.Refresh();
                    pictureBox2.Image = bt2;
                }
            }
            else if (radioButton3.Checked)//robert ����
            {
                bt1 = new Bitmap(pictureBox1.Image);
                bt2 = new Bitmap(pictureBox1.Image);
                int R1, R2, R3, R4, R5, R6, R7, R8, R0;
                int G1, G2, G3, G4, G5, G6, G7, G8, G0;
                int B1, B2, B3, B4, B5, B6, B7, B8, B0;
                int Sxr, Sxg, Sxb, Syr, Syg, Syb;
                for (int i = 1; i < bt1.Width - 1; i++)
                {
                    for (int j = 1; j < bt1.Height - 1; j++)
                    {
                        R1 = bt1.GetPixel(i - 1, j - 1).R;
                        R2 = bt1.GetPixel(i, j - 1).R;
                        R3 = bt1.GetPixel(i + 1, j - 1).R;
                        R4 = bt1.GetPixel(i, j - 1).R;
                        R5 = bt1.GetPixel(i, j + 1).R;
                        R6 = bt1.GetPixel(i + 1, j - 1).R;
                        R7 = bt1.GetPixel(i + 1, j).R;
                        R8 = bt1.GetPixel(i + 1, j + 1).R;
                        Sxr = (R6 + 2 * R7 + R8) - (R1 + 2 * R2 + R3);
                        Syr = (R3 + 2 * R5 + R8) - (R1 + 2 * R4 + R6);
                        R0 = Math.Abs(Sxr) + Math.Abs(Syr);
                        G1 = bt1.GetPixel(i - 1, j - 1).G;
                        G2 = bt1.GetPixel(i, j - 1).G;
                        G3 = bt1.GetPixel(i + 1, j - 1).G;
                        G4 = bt1.GetPixel(i, j - 1).G;
                        G5 = bt1.GetPixel(i, j + 1).G;
                        G6 = bt1.GetPixel(i + 1, j - 1).G;
                        G7 = bt1.GetPixel(i + 1, j).G;
                        G8 = bt1.GetPixel(i + 1, j + 1).G;
                        Sxg = (G6 + 2 * G7 + G8) - (G1 + 2 * G2 + G3);
                        Syg = (G3 + 2 * G5 + G8) - (G1 + 2 * G4 + G6);
                        G0 = Math.Abs(Sxg) + Math.Abs(Syg);
                        B1 = bt1.GetPixel(i - 1, j - 1).B;
                        B2 = bt1.GetPixel(i, j - 1).B;
                        B3 = bt1.GetPixel(i + 1, j - 1).B;
                        B4 = bt1.GetPixel(i, j - 1).B;
                        B5 = bt1.GetPixel(i, j + 1).B;
                        B6 = bt1.GetPixel(i + 1, j - 1).B;
                        B7 = bt1.GetPixel(i + 1, j).B;
                        B8 = bt1.GetPixel(i + 1, j + 1).B;
                        Sxb = (B6 + 2 * B7 + B8) - (B1 + 2 * B2 + B3);
                        Syb = (B3 + 2 * B5 + B8) - (B1 + 2 * B4 + B6);
                        B0 = Math.Abs(Sxb) + Math.Abs(Syb);
                        if (R0 >= 255) R0 = 255;
                        if (G0 >= 255) G0 = 255;//�ж��Ƿ񳬳������������ķ�Χ���������255��ֻ�ܵ���255
                        if (B0 >= 255) B0 = 255;
                        bt2.SetPixel(i, j, Color.FromArgb(R0, G0, B0));
                    }
                    pictureBox2.Refresh();
                    pictureBox2.Image = bt2;
                }
            }
            else if (radioButton4.Checked)//prewitt ����
            {
                bt1 = new Bitmap(pictureBox1.Image);
                bt2 = new Bitmap(pictureBox1.Image);
                int R1, R2, R3, R4, R5, R6, R7, R8, R0;
                int G1, G2, G3, G4, G5, G6, G7, G8, G0;
                int B1, B2, B3, B4, B5, B6, B7, B8, B0;
                int Sxr, Sxg, Sxb, Syr, Syg, Syb;
                for (int i = 1; i < bt1.Width - 1; i++)
                {
                    for (int j = 1; j < bt1.Height - 1; j++)
                    {
                        R1 = bt1.GetPixel(i - 1, j - 1).R;
                        R2 = bt1.GetPixel(i, j - 1).R;
                        R3 = bt1.GetPixel(i + 1, j - 1).R;
                        R4 = bt1.GetPixel(i, j - 1).R;
                        R5 = bt1.GetPixel(i, j + 1).R;
                        R6 = bt1.GetPixel(i + 1, j - 1).R;
                        R7 = bt1.GetPixel(i + 1, j).R;
                        R8 = bt1.GetPixel(i + 1, j + 1).R;
                        Sxr = (R6 + R7 + R8) - (R1 + R2 + R3);
                        Syr = (R3 + R5 + R8) - (R1 + R4 + R6);
                        R0 = Math.Abs(Sxr) + Math.Abs(Syr);
                        G1 = bt1.GetPixel(i - 1, j - 1).G;
                        G2 = bt1.GetPixel(i, j - 1).G;
                        G3 = bt1.GetPixel(i + 1, j - 1).G;
                        G4 = bt1.GetPixel(i, j - 1).G;
                        G5 = bt1.GetPixel(i, j + 1).G;
                        G6 = bt1.GetPixel(i + 1, j - 1).G;
                        G7 = bt1.GetPixel(i + 1, j).G;
                        G8 = bt1.GetPixel(i + 1, j + 1).G;
                        Sxg = (G6 + G7 + G8) - (G1 + G2 + G3);
                        Syg = (G3 + G5 + G8) - (G1 + G4 + G6);
                        G0 = Math.Abs(Sxg) + Math.Abs(Syg);
                        B1 = bt1.GetPixel(i - 1, j - 1).B;
                        B2 = bt1.GetPixel(i, j - 1).B;
                        B3 = bt1.GetPixel(i + 1, j - 1).B;
                        B4 = bt1.GetPixel(i, j - 1).B;
                        B5 = bt1.GetPixel(i, j + 1).B;
                        B6 = bt1.GetPixel(i + 1, j - 1).B;
                        B7 = bt1.GetPixel(i + 1, j).B;
                        B8 = bt1.GetPixel(i + 1, j + 1).B;
                        Sxb = (B6 + B7 + B8) - (B1 + B2 + B3);
                        Syb = (B3 + B5 + B8) - (B1 + B4 + B6);
                        B0 = Math.Abs(Sxb) + Math.Abs(Syb);
                        if (R0 >= 255) R0 = 255;
                        if (G0 >= 255) G0 = 255;//�ж��Ƿ񳬳������������ķ�Χ���������255��ֻ�ܵ���255
                        if (B0 >= 255) B0 = 255;
                        bt2.SetPixel(i, j, Color.FromArgb(R0, G0, B0));
                    }
                    pictureBox2.Refresh();
                    pictureBox2.Image = bt2;
                }
            }
            else if (radioButton5.Checked)//������˹����
            {
                bt1 = new Bitmap(pictureBox1.Image);
                bt2 = new Bitmap(pictureBox1.Image);
                int R1, R2, R3, R4, R5, R6, R7, R8, R9, R;
                int G1, G2, G3, G4, G5, G6, G7, G8, G9, G;
                int B1, B2, B3, B4, B5, B6, B7, B8, B9, B;
                for (int i = 1; i < bt1.Width - 1; i++)
                {
                    for (int j = 1; j < bt1.Height - 1; j++)
                    {
                        R1 = bt1.GetPixel(i - 1, j - 1).R;
                        R2 = bt1.GetPixel(i - 1, j).R;
                        R3 = bt1.GetPixel(i - 1, j + 1).R;
                        R4 = bt1.GetPixel(i, j - 1).R;
                        R5 = bt1.GetPixel(i, j).R;
                        R6 = bt1.GetPixel(i, j + 1).R;
                        R7 = bt1.GetPixel(i + 1, j - 1).R;
                        R8 = bt1.GetPixel(i + 1, j).R;
                        R9 = bt1.GetPixel(i + 1, j + 1).R;
                        R = Math.Abs(R1 + R2 + R3 + R4 + R6 + R7 + R8 + R9 - 8 * R5);
                        G1 = bt1.GetPixel(i - 1, j - 1).G;
                        G2 = bt1.GetPixel(i - 1, j).G;
                        G3 = bt1.GetPixel(i - 1, j + 1).G;
                        G4 = bt1.GetPixel(i, j - 1).G;
                        G5 = bt1.GetPixel(i, j).G;
                        G6 = bt1.GetPixel(i, j + 1).G;
                        G7 = bt1.GetPixel(i + 1, j - 1).G;
                        G8 = bt1.GetPixel(i + 1, j).G;
                        G9 = bt1.GetPixel(i + 1, j + 1).G;
                        G = Math.Abs(G1 + G2 + G3 + G4 + G6 + G7 + G8 + G9 - 8 * G5);
                        B1 = bt1.GetPixel(i - 1, j - 1).B;
                        B2 = bt1.GetPixel(i - 1, j).B;
                        B3 = bt1.GetPixel(i - 1, j + 1).B;
                        B4 = bt1.GetPixel(i, j - 1).B;
                        B5 = bt1.GetPixel(i, j).B;
                        B6 = bt1.GetPixel(i, j + 1).B;
                        B7 = bt1.GetPixel(i + 1, j - 1).B;
                        B8 = bt1.GetPixel(i + 1, j).B;
                        B9 = bt1.GetPixel(i + 1, j + 1).B;
                        B = Math.Abs(B1 + B2 + B3 + B4 + B6 + B7 + B8 + B9 - 8 * B5);
                        if (R >= 255) R = 255;
                        if (G >= 255) G = 255;//�ж��Ƿ񳬳������������ķ�Χ���������255��ֻ�ܵ���255
                    if (B >= 255) B = 255;
                        bt2.SetPixel(i, j, Color.FromArgb(R, G, B));
                    }
                    pictureBox2.Refresh();
                    pictureBox2.Image = bt2;
                }
            }
            else
            {
                MessageBox.Show("δѡ���㷨��");
                return;
            }
        }
    }
}