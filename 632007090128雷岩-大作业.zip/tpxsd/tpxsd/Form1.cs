using System.Drawing.Imaging;

namespace tpxsd
{
    public partial class Form1 : Form
    {
        Image img;
        string name1;
        string name2;
        Bitmap bt1;
        Bitmap bt2;
        int[] a;
        int[] b;
        float end;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)//��ͼƬ1
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = Image.FromFile(openFileDialog1.FileName);
                pictureBox1.Width = pictureBox1.Image.Width;
                pictureBox1.Height = pictureBox1.Image.Height;
                name1 = openFileDialog1.FileName;
            }
        }

        private void button2_Click(object sender, EventArgs e)//��ͼƬ2
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox2.Image = Image.FromFile(openFileDialog1.FileName);
                pictureBox2.Width = pictureBox2.Image.Width;
                pictureBox2.Height = pictureBox2.Image.Height;
                name2 = openFileDialog1.FileName;
            }
        }

        public int[] GetHisogram(Bitmap img)//����ͼ���ֱ��ͼ

        {
            BitmapData data = img.LockBits(new System.Drawing.Rectangle(0, 0, img.Width, img.Height), ImageLockMode.ReadWrite, PixelFormat.Format24bppRgb);
            int[] histogram = new int[256];
            unsafe
            {
                byte* ptr = (byte*)data.Scan0;
                int remain = data.Stride - data.Width * 3;
                for (int i = 0; i < histogram.Length; i++)
                    histogram[i] = 0;
                for (int i = 0; i < data.Height; i++)
                {
                    for (int j = 0; j < data.Width; j++)
                    {
                        int mean = ptr[0] + ptr[1] + ptr[2];
                        mean /= 3;
                        histogram[mean]++;
                        ptr += 3;
                    }
                    ptr += remain;
                }
            }
            img.UnlockBits(data);
            return histogram;
        }

        public Bitmap Resize(string imageFile)//��ͼƬ��Сת��Ϊ256*256
        {            
            img = Image.FromFile(imageFile);
            Bitmap imgOutput = new Bitmap(img, 256, 256);
            return imgOutput;
        }

        private float GetAbs(int firstNum, int secondNum)//���������ľ���ֵ
        {
            float abs = Math.Abs((float)firstNum - (float)secondNum);
            float result = Math.Max(firstNum, secondNum);
            if (result == 0)
                result = 1;
            return abs / result;
        }
        public float GetResult(int[] firstNum, int[] scondNum)//���ռ�����
        {
            if (firstNum.Length != scondNum.Length)
            {
                return 0;
            }
            else
            {
                float result = 0;
                int j = firstNum.Length;
                for (int i = 0; i < j; i++)
                {
                    result += 1 - GetAbs(firstNum[i], scondNum[i]);
                }
                return result / j;
            }

        }
        private void button3_Click(object sender, EventArgs e)
        {
            bt1 = new Bitmap(Resize(name1));
            bt2 = new Bitmap(Resize(name2));
            a = GetHisogram(bt1);
            b = GetHisogram(bt2);
            end = GetResult(a, b);
            MessageBox.Show("���ƶ�Ϊ��"+end.ToString("P"));
        }
    }
}