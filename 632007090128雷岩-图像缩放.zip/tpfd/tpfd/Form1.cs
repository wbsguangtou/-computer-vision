namespace tpfd
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)//��ͼƬ
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = Image.FromFile(openFileDialog1.FileName);
                pictureBox1.Width = pictureBox1.Image.Width;
                pictureBox1.Height = pictureBox1.Image.Height;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Image == null)
            {
                MessageBox.Show("δ��ͼƬ��");
                return;
            }
            if (textBox1.Text.ToString() == null)
            {
                MessageBox.Show("δ�������ű�����");
                return;
            }
            Bitmap bt1 = new Bitmap(pictureBox1.Image);
            double b = 0;
            b = Convert.ToDouble(textBox1.Text.ToString());
            if(b < 0)
            {
                MessageBox.Show("���������0�ı�����");
                    return;
            }
            int width = bt1.Width;
            int height = bt1.Height;
            int newWidth = (int)Math.Round(width * b);
            int newHeight = (int)Math.Round(height * b);
            Bitmap bt = new Bitmap(newWidth, newHeight);
            for (int i = 1; i < newWidth; i++)
            {
                for (int j = 1; j < newHeight; j++)
                {
                    int m = (int)Math.Round(i * (1 / b));
                    int n = (int)Math.Round(j * (1 / b));
                    if (m > width - 1)
                        m = width - 1;
                    if (n > height - 1)
                        n = height - 1;
                    bt.SetPixel(i, j, bt1.GetPixel(m, n));
                }
                pictureBox2.Refresh();
                pictureBox2.Image = bt;
                pictureBox2.Width = newWidth;
                pictureBox2.Height = newHeight;
            }
        }
    }
}