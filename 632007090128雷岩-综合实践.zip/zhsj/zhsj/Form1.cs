using System.Windows.Forms;

namespace zhsj
{
    public partial class Form1 : Form
    {
        Bitmap bt1;
        Bitmap bt2;
        Bitmap btmp;
        Bitmap btm;
        bool flage = false;//�ж��Ƿ�ҶȻ�
        bool flage1 = false;//�ж��Ƿ����
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)//��ͼƬ
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = Image.FromFile(openFileDialog1.FileName);
                pictureBox1.Width = pictureBox1.Image.Width;
                pictureBox1.Height = pictureBox1.Image.Height;
                btmp = new Bitmap(pictureBox1.Image);//����Bitmap�Ի�ȡ��ͼƬ�����ص�
                btm = new Bitmap(pictureBox1.Image);
            }
        }

        private void button2_Click(object sender, EventArgs e)//ͼ��ҶȻ�
        {
            if (pictureBox1.Image == null)
            {
                MessageBox.Show("δ��ͼƬ��");
                return;
            }
            bt1 = new Bitmap(pictureBox1.Image);
            bt2 = new Bitmap(pictureBox1.Image);
            Color color = new Color();
            for (int i = 0; i < bt1.Width; i++)
            {
                for (int j = 0; j < bt1.Height; j++)
                {
                    color = bt1.GetPixel(i, j);
                    int n = (int)((color.G * 59 + color.R * 30 + color.B * 11) / 100);
                    bt2.SetPixel(i, j, Color.FromArgb(n, n, n));

                }
                pictureBox2.Refresh();
                pictureBox2.Image = bt2;
            }
            flage = true;
        }

        private void button3_Click(object sender, EventArgs e)//ͼ���ֵ��
        {
            Color p1;
            Bitmap bt1 = btmp.Clone() as Bitmap;
            for (int x1 = 0; x1 < btmp.Width; x1++)
            {
                for (int x2 = 0; x2 < btmp.Height; x2++)
                {
                    p1 = btmp.GetPixel(x1, x2);
                    int temp = (p1.R + p1.B + p1.G) / 3;
                    bt1.SetPixel(x1, x2, Color.FromArgb(temp, temp, temp));
                }
            }

            Color p2;
            for (int x1 = 0; x1 < bt1.Width; x1++)
            {
                for (int x2 = 0; x2 < bt1.Height; x2++)
                {
                    p2 = bt1.GetPixel(x1, x2);
                    if (p2.G > 150)
                    {
                        bt1.SetPixel(x1, x2, Color.FromArgb(255, 255, 255));
                    }
                    else
                    {
                        bt1.SetPixel(x1, x2, Color.FromArgb(0, 0, 0));
                    }
                }
            }
            pictureBox2.Refresh();
            pictureBox2.Image = bt1;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void trackBar1_Scroll(object sender, EventArgs e)//H��������
        {
            textBox1.Text = trackBar1.Value.ToString();
        }

        private void trackBar2_Scroll(object sender, EventArgs e)//S��������
        {
            textBox2.Text = trackBar2.Value.ToString();
        }

        private void trackBar3_Scroll(object sender, EventArgs e)//I��������
        {
            textBox3.Text = trackBar3.Value.ToString();
        }

        private void button6_Click(object sender, EventArgs e)//���Ͷȵ���
        {
            if (pictureBox1.Image == null)
            {
                MessageBox.Show("����û�е���ͼƬ��");
                return;
            }
            bt1 = new Bitmap(pictureBox1.Image);
            bt2 = new Bitmap(pictureBox1.Image);
            Color color = new Color();
            int H = trackBar1.Value;
            int S = trackBar2.Value;
            int I = trackBar3.Value; 
            int Red, Green, Blue;
            double Hudu = Math.PI / 180;
            //����H�ĽǶ�ֵ�ֲ���ͬʱ�������в��죬��˷ֳɼ������
            if (H >= 0 && H <= 120)
            {
                for (int i = 0; i < bt1.Width; i++)
                {
                    for (int j = 0; j < bt1.Height; j++)
                    {
                        int R, G, B;
                        color = bt1.GetPixel(i, j);
                        R = color.R;
                        G = color.G;
                        B = color.B;
                        Blue = B + I * (I - S); //����ת����ʽ����ԭ��RGB���������ϼ��ϵ�����ֵ
                        Red = (int)(R + I * (1 + (S * Math.Cos(H * Hudu) / (Math.Cos((60 - H) *Hudu)))));
                        Green = G + 3 * I - (Blue + Red);
                        if (Red > 255) Red = 255; //�ж��Ƿ񳬳������������ķ�Χ���������255��ֻ�ܵ���255
                        if (Red < 0) Red = 0; //���С��0��ֻ�ܵ���0
                        if (Green > 255) Green = 255;
                        if (Green < 0) Green = 0;
                        if (Blue > 255) Blue = 255;
                        if (Blue < 0) Blue = 0;
                        bt2.SetPixel(i, j, Color.FromArgb(Red, Green, Blue));
                    }
                    pictureBox2.Refresh();
                    pictureBox2.Image = bt2;
                }
            }
            if (H > 120 && H <= 240)
            {
                for (int i = 0; i < bt1.Width; i++)
                {
                    for (int j = 0; j < bt1.Height; j++)
                    {
                        int R, G, B;
                        color = bt1.GetPixel(i, j);
                        R = color.R;
                        G = color.G;
                        B = color.B;
                        Red = R + I * (I - S); //����ת����ʽ����ԭ��RGB���������ϼ��ϵ�����ֵ
                        Green = (int)(G + I * (1 + (S * Math.Cos((H - 120) * Hudu) / (Math.Cos((180 - H) * Hudu)))));
                        Blue = B + 3 * I - (Green + Red);
                        if (Red > 255) Red = 255; //�ж��Ƿ񳬳������������ķ�Χ���������255��ֻ�ܵ���255
                        if (Red < 0) Red = 0; //���С��0��ֻ�ܵ���0
                        if (Green > 255) Green = 255;
                        if (Green < 0) Green = 0;
                        if (Blue > 255) Blue = 255;
                        if (Blue < 0) Blue = 0;
                        bt2.SetPixel(i, j, Color.FromArgb(Red, Green, Blue));
                    }
                    pictureBox2.Refresh();
                    pictureBox2.Image = bt2;
                }
            }
            if (H > 240 && H <= 360)
            {
                for (int i = 0; i < bt1.Width; i++)
                {
                    for (int j = 0; j < bt1.Height; j++)
                    {
                        int R, G, B;
                        color = bt1.GetPixel(i, j);
                        R = color.R;
                        G = color.G;
                        B = color.B;
                        Green = G + I * (I - S); //����ת����ʽ����ԭ��RGB���������ϼ��ϵ�����ֵ
                        Blue = (int)(B + I * (1 + (S * Math.Cos((H - 120) * Hudu) / (Math.Cos((300 - H)* Hudu)))));
                        Red = R + 3 * I - (Blue + Green);
                        if (Red > 255) Red = 255; //�ж��Ƿ񳬳������������ķ�Χ���������255��ֻ�ܵ���255
                        if (Red < 0) Red = 0; //���С��0��ֻ�ܵ���0
                        if (Green > 255) Green = 255;
                        if (Green < 0) Green = 0;
                        if (Blue > 255) Blue = 255;
                        if (Blue < 0) Blue = 0;
                        bt2.SetPixel(i, j, Color.FromArgb(Red, Green, Blue));
                    }
                    pictureBox2.Refresh();//���⽨����һ��ͼƬ��������ʾ�������ͼ��
                    pictureBox2.Image = bt2;
                }
            }
        }

        private void trackBar4_Scroll(object sender, EventArgs e)//���ȵ��ڻ���
        {
            textBox4.Text = trackBar4.Value.ToString();
        }

        private void button5_Click(object sender, EventArgs e)//�Աȶȵ���
        {
            if (pictureBox1.Image == null)
            {
                MessageBox.Show("����û�е���ͼƬ��");
                return;
            }
            int degree = int.Parse(textBox6.Text);
            int r, g, b;
            Bitmap bt = btmp;
            Bitmap bt1 = new Bitmap(pictureBox1.Image);
            for (int i = 0; i < bt1.Width; i++)
            {
                for (int j = 0; j < bt1.Height; j++)
                {
                    Color c = bt.GetPixel(i, j);
                    r = c.R;
                    g = c.G;
                    b = c.B;
                    int rg = (Math.Abs(127 - r) * degree) / 255;
                    int gg = (Math.Abs(127 - g) * degree) / 255;
                    int bg = (Math.Abs(127 - b) * degree) / 255;
                    if (r > 127) r = r + rg;
                    else r = r - rg;
                    if (g > 127) g = g + gg;
                    else g = g - gg;
                    if (b > 127) b = b + bg;
                    else b = b - bg;
                    if (r > 255) r = 255;
                    if (r < 0) r = 0;
                    if (g > 255) g = 255;
                    if (g < 0) g = 0;
                    if (b > 255) b = 255;
                    if (b < 0) b = 0;
                    Color c1 = Color.FromArgb(r, g, b);
                    bt1.SetPixel(i, j, c1);
                }
                pictureBox2.Refresh();
                pictureBox2.Image = bt1;
            }
        }

        private void button4_Click(object sender, EventArgs e)//���ȵ���
        {
            if (pictureBox1.Image == null)
            {
                MessageBox.Show("����û�е���ͼƬ��");
                return;
            }
            int value = int.Parse(textBox1.Text);
            Bitmap bt = new Bitmap(pictureBox1.Image);
            Bitmap bt1 = new Bitmap(pictureBox1.Image);
            int r, g, b;
            for (int i = 0; i < bt1.Width; i++)
            {
                for (int j = 0; j < bt1.Height; j++)
                {
                    Color color = bt.GetPixel(i, j);
                    r = color.R;
                    g = color.G;
                    b = color.B;
                    r += value;
                    g += value;
                    b += value;
                    if (r > 255)
                        r = 255;
                    if (r < 0)
                        r = 0;
                    if (g > 255)
                        g = 255;
                    if (g < 0)
                        g = 0;
                    if (b > 255)
                        b = 255;
                    if (b < 0)
                        b = 0;
                    Color c1 = Color.FromArgb(r, g, b);
                    bt1.SetPixel(i, j, c1);
                }
                pictureBox2.Refresh();
                pictureBox2.Image = bt1;
            }
        }

        private void button8_Click(object sender, EventArgs e)//ͼ��ԭ
        {
            pictureBox1.Refresh();
            pictureBox1.Image = btm;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)//α��ɫ����
        {
            if (pictureBox1.Image == null)
            {
                MessageBox.Show("δ��ͼƬ��");
                return;
            }
            else if (!flage)
            {
                MessageBox.Show("δ���лҶȻ���");
                return;
            }
            bt1 = new Bitmap(pictureBox1.Image);
            bt2 = new Bitmap(pictureBox1.Image);
            Color c = new Color();
            int tGray = 0, r = 0, g = 0, b = 0;
            for (int i = 1; i < bt1.Width; i++)
            {
                for (int j = 1; j < bt1.Height; j++)
                {
                    c = bt1.GetPixel(i, j);
                    tGray = (int)(c.R * 0.114 + c.G * 0.587 + c.B * 0.299);
                    if (tGray >= 0 && tGray <= 63)
                    {
                        r = 0;
                        g = 254 - 4 * tGray;
                        b = 255;
                    }
                    if (tGray >= 64 && tGray <= 127)
                    {
                        r = 0;
                        g = 4 * tGray - 254;
                        b = 510 - 4 * tGray;
                    }
                    if (tGray >= 128 && tGray <= 191)
                    {
                        r = 4 * tGray - 510;
                        g = 255;
                        b = 0;
                    }
                    if (tGray >= 192 && tGray <= 255)
                    {
                        r = 255;
                        g = 1022 - 4 * tGray;
                        b = 0;
                    }
                    bt2.SetPixel(i, j, Color.FromArgb(r, g, b));
                }
                pictureBox2.Refresh();//ˢ��ͼƬ��
                pictureBox2.Image = bt2;
            }
        }

        private void button10_Click(object sender, EventArgs e)//�������
        {
            if (pictureBox1.Image == null)
            {
                MessageBox.Show("����û�е���ͼƬ��");
                return;
            }
            bt1 = new Bitmap(pictureBox1.Image);
            bt2 = new Bitmap(pictureBox1.Image);
            Random random = new Random();
            for (int i = 0; i < bt1.Width; i++)
            {
                for (int j = 0; j < bt1.Height; j++)
                {
                    int R, G, B;
                    double ran1 = random.NextDouble();//���0-1�������
                    int a = random.Next(0, 30);
                    int b = random.Next(0, 30);
                    int c = random.Next(0, 30);
                    R = bt1.GetPixel(i, j).R;
                    G = bt1.GetPixel(i, j).G;
                    B = bt1.GetPixel(i, j).B;
                    if (ran1 > 0.85)//������������0.85�򽫸õ���Ϊ���ɫֵ
                    {
                        R = 255 - a;
                        G = 255 - b;
                        B = 255 - c;
                    }
                    if (ran1 < 0.15)//��������С��0.15�򽫸õ���Ϊ���ɫֵ
                    {
                        R = a;
                        G = b;
                        B = c;
                    }
                    bt2.SetPixel(i, j, Color.FromArgb(R, G, B));
                }
                pictureBox2.Refresh();
                pictureBox2.Image = bt2;
            }
            flage1 = true;
        }

        private void button11_Click(object sender, EventArgs e)//��������
        {
            if (pictureBox1.Image == null)
            {
                MessageBox.Show("����û�е���ͼƬ��");
                return;
            }
            bt1 = new Bitmap(pictureBox1.Image);
            bt2 = new Bitmap(pictureBox1.Image);
            Random random = new Random();
            double Pa = 0.1;
            double Pb = 0.1;
            double P = Pb / (1 - Pa);
            for (int i = 0; i < bt1.Height; i++)
            {
                for (int j = 0; j < bt1.Width; j++)
                {
                    int gray;
                    int noise = 1;
                    double ran1 = random.NextDouble();
                    if (ran1 < Pa)
                    {
                        noise = 255;
                    }
                    else
                    {
                        double ran2 = random.NextDouble();
                        if (ran2 < P)
                            noise = 0;
                    }
                    if (noise != 1)
                    {
                        gray = noise;
                    }
                    else
                        gray = bt1.GetPixel(j, i).R;
                    Color color = Color.FromArgb(gray, gray, gray);
                    bt2.SetPixel(j, i, color);
                }
            }
            flage1 = true;
        }

        private void button12_Click(object sender, EventArgs e)//ͼ��ȥ��
        {
            if (pictureBox1.Image == null)
            {
                MessageBox.Show("δ��ͼƬ��");
                return;
            }
            else if(!flage1)
            {
                MessageBox.Show("δ��ɼ��룡");
                return;
            }
            if(radioButton1.Checked)//������ƽ��
            {
                bt1 = new Bitmap(pictureBox2.Image);
                bt2 = new Bitmap(pictureBox2.Image); //��������λͼ����
                int R1, R2, R3, R4, Red;
                int G1, G2, G3, G4, Green;
                int B1, B2, B3, B4, Blue;
                for (int i = 1; i < bt1.Width - 1; i++)
                {
                    for (int j = 1; j < bt1.Height - 1; j++)
                    {
                        R1 = bt1.GetPixel(i, j - 1).R;
                        R2 = bt1.GetPixel(i, j + 1).R;
                        R3 = bt1.GetPixel(i - 1, j).R;
                        R4 = bt1.GetPixel(i + 1, j).R;
                        Red = (R1 + R2 + R3 + R4) / 5;
                        G1 = bt1.GetPixel(i, j - 1).G;
                        G2 = bt1.GetPixel(i, j + 1).G;
                        G3 = bt1.GetPixel(i - 1, j).G;
                        G4 = bt1.GetPixel(i + 1, j).G;
                        Green = (G1 + G2 + G3 + G4) / 5;
                        B1 = bt1.GetPixel(i, j - 1).B;
                        B2 = bt1.GetPixel(i, j + 1).B;
                        B3 = bt1.GetPixel(i - 1, j).B;
                        B4 = bt1.GetPixel(i + 1, j).B;
                        Blue = (B1 + B2 + B3 + B4) / 5;
                        bt2.SetPixel(i, j, Color.FromArgb(Red, Green, Blue));
                    }
                    pictureBox2.Refresh();//ˢ��ͼƬ��
                    pictureBox2.Image = bt2;
                }
            }
            else if(radioButton2.Checked)//������ƽ��
            {
                bt1 = new Bitmap(pictureBox2.Image);
                bt2 = new Bitmap(pictureBox2.Image); //��������λͼ����
                int R1, R2, R3, R4, R5, R6, R7, R8, Red;
                int G1, G2, G3, G4, G5, G6, G7, G8, Green;
                int B1, B2, B3, B4, B5, B6, B7, B8, Blue;
                for (int i = 1; i < bt1.Width - 1; i++)
                {
                    for (int j = 1; j < bt1.Height - 1; j++)
                    {
                        R1 = bt1.GetPixel(i - 1, j - 1).R;
                        R2 = bt1.GetPixel(i, j - 1).R;
                        R3 = bt1.GetPixel(i + 1, j - 1).R;
                        R4 = bt1.GetPixel(i - 1, j).R;
                        R5 = bt1.GetPixel(i + 1, j).R;
                        R6 = bt1.GetPixel(i - 1, j + 1).R;
                        R7 = bt1.GetPixel(i, j + 1).R;
                        R8 = bt1.GetPixel(i + 1, j + 1).R;
                        Red = (int)(R1 + R2 + R3 + R4 + R5 + R6 + R7 + R8) / 8;
                        G1 = bt1.GetPixel(i - 1, j - 1).G;
                        G2 = bt1.GetPixel(i, j - 1).G;
                        G3 = bt1.GetPixel(i + 1, j - 1).G;
                        G4 = bt1.GetPixel(i - 1, j).G;
                        G5 = bt1.GetPixel(i + 1, j).G;
                        G6 = bt1.GetPixel(i - 1, j + 1).G;
                        G7 = bt1.GetPixel(i, j + 1).G;
                        G8 = bt1.GetPixel(i + 1, j + 1).G;
                        Green = (int)(G1 + G2 + G3 + G4 + G5 + G6 + G7 + G8) / 8;
                        B1 = bt1.GetPixel(i - 1, j - 1).B;
                        B2 = bt1.GetPixel(i, j - 1).B;
                        B3 = bt1.GetPixel(i + 1, j - 1).B;
                        B4 = bt1.GetPixel(i - 1, j).B;
                        B5 = bt1.GetPixel(i + 1, j).B;
                        B6 = bt1.GetPixel(i - 1, j + 1).B;
                        B7 = bt1.GetPixel(i, j + 1).B;
                        B8 = bt1.GetPixel(i + 1, j + 1).B;
                        Blue = (int)(B1 + B2 + B3 + B4 + B5 + B6 + B7 + B8) / 8;
                        bt2.SetPixel(i, j, Color.FromArgb(Red, Green, Blue));
                    }
                    pictureBox2.Refresh();//ˢ��ͼƬ��
                    pictureBox2.Image = bt2;
                }
            }
            else if(radioButton3.Checked)//��ֵ�˲�
            {
                Color c = new Color();
                bt1 = new Bitmap(pictureBox2.Image);
                bt2 = new Bitmap(pictureBox2.Image);
                int rr, r1, dm, m;
                int[] dt = new int[20];
                for (int i = 1; i < bt1.Width - 1; i++)
                {
                    for (int j = 1; j < bt1.Height - 1; j++)
                    {
                        rr = 0; m = 0;
                        for (int k = -1; k < 2; k++)
                        {
                            for (int n = -1; n < 2; n++)
                            {
                                c = bt1.GetPixel(i + k, j + n);
                                r1 = c.R;
                                dt[m++] = r1;
                            }
                        }
                        for (int p = 0; p < m - 1; p++)
                        {
                            for (int q = p + 1; q < m; q++)
                            {
                                if (dt[p] > dt[q])
                                {
                                    dm = dt[p];
                                    dt[p] = dt[q];
                                    dt[q] = dm;
                                }
                            }
                        }
                        rr = dt[(int)(m / 2)];
                        bt2.SetPixel(i, j, Color.FromArgb(rr, rr, rr));
                    }
                    pictureBox2.Refresh();
                    pictureBox2.Image = bt2;
                }
            }
            else if(radioButton4.Checked)//����ƽ���˲�
            {
                Color c = new Color();
                bt1 = new Bitmap(pictureBox2.Image);
                bt2 = new Bitmap(pictureBox2.Image);
                int rr, r1, dm, m;
                int[] dt = new int[20];
                for (int i = 1; i < bt1.Width - 1; i++)
                {
                    for (int j = 1; j < bt1.Height - 1; j++)
                    {
                        rr = 0; m = 0;
                        for (int k = -1; k < 2; k++)
                        {
                            for (int n = -1; n < 2; n++)
                            {
                                c = bt1.GetPixel(i + k, j + n);
                                r1 = c.R;
                                dt[m] = r1;
                                m++;
                            }
                        }
                        for (int p = 0; p < m - 1; p++)
                        {
                            for (int q = p + 1; q < m; q++)
                            {
                                if (dt[p] > dt[q])
                                {
                                    dm = dt[p];
                                    dt[p] = dt[q];
                                    dt[q] = dm;
                                }
                            }
                        }
                        for (int l = 1; l < m - 1; l++)
                            rr += dt[l];
                        rr = (int)(rr / (m - 2));
                        bt2.SetPixel(i, j, Color.FromArgb(rr, rr, rr));
                    }
                    pictureBox2.Refresh();
                    pictureBox2.Image = bt2;
                }
            }
            else
            {
                MessageBox.Show("δѡ���㷨��");
                return;
            }
            flage = false;
        }

        private void button7_Click(object sender, EventArgs e)//ͼƬ�Ŵ�
        {
            if (pictureBox1.Image == null)
            {
                MessageBox.Show("δ��ͼƬ��");
                return;
            }
            if (textBox5.Text.ToString() == null)
            {
                MessageBox.Show("δ�������ű�����");
                return;
            }
            Bitmap bt1 = new Bitmap(pictureBox1.Image);
            double b = 0;
            b = Convert.ToDouble(textBox5.Text.ToString());
            if (b < 0)
            {
                MessageBox.Show("���������0�ı�����");
                return;
            }
            int width = bt1.Width;
            int height = bt1.Height;
            int newWidth = (int)Math.Round(width * b);
            int newHeight = (int)Math.Round(height * b);
            Bitmap bt = new Bitmap(newWidth, newHeight);
            for (int i = 1; i < newWidth; i++)
            {
                for (int j = 1; j < newHeight; j++)
                {
                    int m = (int)Math.Round(i * (1 / b));
                    int n = (int)Math.Round(j * (1 / b));
                    if (m > width - 1)
                        m = width - 1;
                    if (n > height - 1)
                        n = height - 1;
                    bt.SetPixel(i, j, bt1.GetPixel(m, n));
                }
                pictureBox2.Refresh();
                pictureBox2.Image = bt;
                pictureBox2.Width = newWidth;
                pictureBox2.Height = newHeight;
            }
        }

        private void trackBar5_Scroll(object sender, EventArgs e)//�Աȶȵ��ڻ���
        {
            textBox6.Text = trackBar5.Value.ToString();
        }
    }
}